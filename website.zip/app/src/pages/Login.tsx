import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router";
import { LogIn } from "lucide-react";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  return (
    <div
      className="min-h-screen flex items-center justify-center px-4"
      style={{ background: "#F7F7F7" }}
    >
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-0">
            <span className="font-display text-3xl font-bold text-[#111111]">
              ScholarHub
            </span>
            <span className="text-[#D4A843] text-3xl font-bold ml-0.5">.</span>
          </Link>
          <p className="text-sm text-[#888888] mt-2">
            Sign in to access your learning journey
          </p>
        </div>

        <Card className="border-0 shadow-lg">
          <CardHeader className="text-center pb-2">
            <CardTitle className="text-lg font-semibold text-[#111111]">
              Welcome Back
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            <Button
              className="w-full bg-[#1E3A5F] hover:bg-[#152d4a] text-white h-12"
              size="lg"
              onClick={() => {
                window.location.href = getOAuthUrl();
              }}
            >
              <LogIn className="w-4 h-4 mr-2" />
              Sign in with Google
            </Button>

            <p className="text-xs text-center text-[#888888] mt-4">
              By signing in, you agree to our Terms of Service and Privacy Policy
            </p>
          </CardContent>
        </Card>

        <div className="text-center mt-6">
          <Link
            to="/"
            className="text-sm text-[#1E3A5F] hover:underline font-medium"
          >
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
