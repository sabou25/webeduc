import Header from "@/components/Header";
import HeroSection from "@/sections/HeroSection";
import ArticlesSection from "@/sections/ArticlesSection";
import CoursesSection from "@/sections/CoursesSection";
import VideosSection from "@/sections/VideosSection";
import ProjectsSection from "@/sections/ProjectsSection";
import Footer from "@/sections/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#F7F7F7]">
      <Header />
      <main>
        <HeroSection />
        <ArticlesSection />
        <CoursesSection />
        <VideosSection />
        <ProjectsSection />
      </main>
      <Footer />
    </div>
  );
}
