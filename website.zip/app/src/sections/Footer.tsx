import { Link } from "react-router";

const exploreLinks = [
  { label: "Articles", href: "#articles" },
  { label: "Courses", href: "#courses" },
  { label: "Videos", href: "#videos" },
  { label: "Projects", href: "#projects" },
];

const resourceLinks = [
  { label: "Help Center", href: "#" },
  { label: "Community", href: "#" },
  { label: "Blog", href: "#" },
  { label: "API", href: "#" },
];

const connectLinks = [
  { label: "Twitter", href: "#" },
  { label: "LinkedIn", href: "#" },
  { label: "YouTube", href: "#" },
  { label: "GitHub", href: "#" },
];

export default function Footer() {
  const handleNavClick = (href: string) => {
    if (href.startsWith("#")) {
      const id = href.replace("#", "");
      const el = document.getElementById(id);
      if (el) {
        el.scrollIntoView({ behavior: "smooth" });
      }
    }
  };

  return (
    <footer className="bg-[#111111]" style={{ padding: "64px 0 32px" }}>
      <div className="mx-auto px-6 lg:px-12" style={{ maxWidth: 1280 }}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center gap-0">
              <span className="font-display text-xl font-bold text-white">
                ScholarHub
              </span>
              <span className="text-[#D4A843] text-xl font-bold ml-0.5">.</span>
            </Link>
            <p className="text-sm text-white/50 mt-3">
              Empowering learners worldwide
            </p>
          </div>

          {/* Explore */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Explore</h4>
            <ul className="space-y-2.5">
              {exploreLinks.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => handleNavClick(link.href)}
                    className="text-sm text-white/60 hover:text-white transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Resources</h4>
            <ul className="space-y-2.5">
              {resourceLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-white/60 hover:text-white transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Connect</h4>
            <ul className="space-y-2.5">
              {connectLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-white/60 hover:text-white transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/10 mt-12 pt-6">
          <p className="text-xs text-white/40">
            2025 ScholarHub. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
