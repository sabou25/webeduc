import { useEffect, useRef, useState } from "react";
import { trpc } from "@/providers/trpc";
import { X, ExternalLink } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

interface ProjectAuthor {
  name: string;
  avatar?: string;
}

export default function ProjectsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<{
    id: number;
    title: string;
    description: string | null;
    fullDescription: string | null;
    coverImage: string | null;
    authors: unknown;
    tags: unknown;
    externalUrl: string | null;
    category: string | null;
  } | null>(null);

  const { data } = trpc.project.list.useQuery({ limit: 6 });

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const cards = section.querySelectorAll(".project-card");
    const header = section.querySelector(".section-header");

    gsap.set(cards, { opacity: 0, y: 30 });
    if (header) gsap.set(header, { opacity: 0, y: 30 });

    const triggers: ScrollTrigger[] = [];

    if (header) {
      triggers.push(
        ScrollTrigger.create({
          trigger: header,
          start: "top 85%",
          onEnter: () => {
            gsap.to(header, { opacity: 1, y: 0, duration: 0.6, ease: "power2.out" });
          },
          once: true,
        })
      );
    }

    cards.forEach((card, i) => {
      triggers.push(
        ScrollTrigger.create({
          trigger: card,
          start: "top 85%",
          onEnter: () => {
            gsap.to(card, {
              opacity: 1,
              y: 0,
              duration: 0.6,
              delay: i * 0.08,
              ease: "power2.out",
            });
          },
          once: true,
        })
      );
    });

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, [data]);

  const fallbackProjects = [
    {
      id: 1,
      title: "Sustainable Urban Living: Eco-Hub Architecture",
      slug: "sustainable-urban-living",
      description: "A comprehensive architectural proposal for sustainable mixed-use developments that reduce carbon footprint by 60% while improving quality of life.",
      fullDescription: "The Eco-Hub project reimagines urban residential spaces through the lens of sustainability and community. Our team designed a mixed-use development that integrates vertical gardens, solar harvesting facades, and communal spaces to reduce environmental impact while fostering social connection.",
      coverImage: "/project-1.jpg",
      authors: [{ name: "Maria Garcia" }, { name: "David Park" }],
      tags: ["Architecture", "Sustainability", "Urban Design"],
      category: "Engineering",
      featured: true,
    },
    {
      id: 2,
      title: "StudyFlow: Productivity App for Students",
      slug: "studyflow-app",
      description: "A mobile application that uses Pomodoro timing, spaced repetition, and AI-powered scheduling to help students optimize their study habits.",
      fullDescription: "StudyFlow is a comprehensive student productivity platform built with React Native and Firebase. The app combines evidence-based study techniques with modern UX design to create an intuitive and effective learning companion.",
      coverImage: "/project-2.jpg",
      authors: [{ name: "Alex Johnson" }, { name: "Priya Sharma" }, { name: "Tom Williams" }],
      tags: ["Mobile App", "React Native", "EdTech"],
      category: "Technology",
      featured: false,
    },
    {
      id: 3,
      title: "Cellular Metabolism Research Initiative",
      slug: "cellular-metabolism-research",
      description: "Novel research into metabolic pathways reveals potential therapeutic targets for metabolic disorders and age-related diseases.",
      fullDescription: "This research project investigated previously unexplored regulatory mechanisms in cellular metabolism. Using CRISPR-based screening and metabolomics profiling, our team identified three novel enzymes that play critical roles in mitochondrial function.",
      coverImage: "/project-3.jpg",
      authors: [{ name: "Dr. Ana Silva" }, { name: "Prof. Ben Carter" }],
      tags: ["Biology", "Research", "CRISPR"],
      category: "Life Sciences",
      featured: true,
    },
    {
      id: 4,
      title: "AutoGardener: Smart Hydroponics System",
      slug: "autogardener-hydroponics",
      description: "An Arduino-powered automated hydroponics system that monitors plant health, adjusts nutrient delivery, and harvests crops with minimal human intervention.",
      fullDescription: "AutoGardener brings the future of agriculture to your home. This open-source project combines IoT sensors, machine learning, and robotics to create a fully automated indoor farming system.",
      coverImage: "/project-4.jpg",
      authors: [{ name: "Lisa Chen" }, { name: "Marcus Johnson" }],
      tags: ["Robotics", "IoT", "Agriculture"],
      category: "Engineering",
      featured: false,
    },
    {
      id: 5,
      title: "Global Learning Analytics Dashboard",
      slug: "learning-analytics-dashboard",
      description: "A comprehensive data visualization platform that helps educators track student engagement, predict at-risk learners, and optimize curriculum design.",
      fullDescription: "The Global Learning Analytics Dashboard aggregates data from multiple learning management systems to provide educators with actionable insights. The platform uses machine learning to identify patterns in student behavior and predict academic outcomes.",
      coverImage: "/project-5.jpg",
      authors: [{ name: "Ryan Foster" }, { name: "Nina Patel" }, { name: "Oscar Martinez" }],
      tags: ["Data Science", "Visualization", "EdTech"],
      category: "Technology",
      featured: true,
    },
    {
      id: 6,
      title: "Immersive Histories: VR Museum Experience",
      slug: "immersive-histories-vr",
      description: "A virtual reality museum exhibit that transports visitors to historical events, allowing them to experience the past through immersive storytelling.",
      fullDescription: "Immersive Histories uses cutting-edge VR technology to bring historical events to life. Visitors can walk through ancient Rome, witness the signing of the Declaration of Independence, or explore the streets of Victorian London.",
      coverImage: "/project-6.jpg",
      authors: [{ name: "Sophia Lee" }, { name: "Jake Thompson" }],
      tags: ["VR", "Interactive", "History"],
      category: "Arts",
      featured: false,
    },
  ];

  const projects = data?.items ?? fallbackProjects;

  const openModal = (project: (typeof projects)[0]) => {
    setSelectedProject(project);
    setModalOpen(true);
    document.body.style.overflow = "hidden";
  };

  const closeModal = () => {
    setModalOpen(false);
    document.body.style.overflow = "";
  };

  // Parse authors and tags safely
  const getAuthors = (authors: unknown): ProjectAuthor[] => {
    if (Array.isArray(authors)) return authors as ProjectAuthor[];
    return [];
  };

  const getTags = (tags: unknown): string[] => {
    if (Array.isArray(tags)) return tags as string[];
    return [];
  };

  return (
    <>
      <section
        id="projects"
        ref={sectionRef}
        className="bg-white"
        style={{ padding: "120px 0" }}
      >
        <div className="mx-auto px-6 lg:px-12" style={{ maxWidth: 1280 }}>
          <div className="section-header">
            <span className="font-mono-label text-xs uppercase tracking-[0.1em] text-[#D4A843]">
              PROJECTS
            </span>
            <h2 className="font-display text-[clamp(2rem,5vw,3.5rem)] font-semibold text-[#111111] mt-3 leading-tight">
              Student & Faculty Work
            </h2>
            <p className="text-base text-[#888888] mt-3 max-w-[480px]">
              Showcasing research, creative work, and collaborative initiatives.
            </p>
          </div>

          {/* Masonry Grid */}
          <div className="columns-1 md:columns-2 lg:columns-3 gap-6 mt-16 space-y-6">
            {projects.map((project, index) => {
              const authors = getAuthors(project.authors);
              const tags = getTags(project.tags);
              // Alternate aspect ratios for masonry effect
              const aspectClasses = [
                "aspect-[3/4]",
                "aspect-[4/3]",
                "aspect-[3/4]",
                "aspect-[4/3]",
                "aspect-[3/4]",
                "aspect-[4/3]",
              ];

              return (
                <div
                  key={project.id}
                  className={`project-card break-inside-avoid relative rounded-lg overflow-hidden cursor-pointer group ${aspectClasses[index % aspectClasses.length]}`}
                  onClick={() => openModal(project)}
                >
                  <img
                    src={project.coverImage || "/project-1.jpg"}
                    alt={project.title}
                    className="w-full h-full object-cover"
                  />
                  {/* Hover overlay */}
                  <div className="absolute inset-0 bg-[rgba(30,58,95,0.9)] backdrop-blur-sm translate-y-full group-hover:translate-y-0 transition-transform duration-400 flex flex-col justify-end p-6">
                    <h3 className="text-lg font-semibold text-white">
                      {project.title}
                    </h3>
                    <p className="text-sm text-white/70 mt-1">
                      {authors.map((a) => a.name).join(", ")}
                    </p>
                    <div className="flex flex-wrap gap-2 mt-3">
                      {tags.map((tag) => (
                        <span
                          key={tag}
                          className="text-xs text-white/80 border border-white/30 px-2.5 py-1 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Project Modal */}
      {modalOpen && selectedProject && (
        <div
          className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={closeModal}
        >
          <div
            className="relative bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
            style={{
              animation: "modalSlideUp 0.4s ease forwards",
            }}
          >
            <button
              onClick={closeModal}
              className="absolute top-4 right-4 w-10 h-10 rounded-full bg-[#F7F7F7] flex items-center justify-center hover:bg-[#E5E5E5] transition-colors z-10"
            >
              <X className="w-5 h-5 text-[#111111]" />
            </button>

            {selectedProject.coverImage && (
              <div className="aspect-video w-full overflow-hidden rounded-t-xl">
                <img
                  src={selectedProject.coverImage}
                  alt={selectedProject.title}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            <div className="p-8">
              <h2 className="font-display text-2xl font-semibold text-[#111111]">
                {selectedProject.title}
              </h2>

              <div className="flex flex-wrap gap-2 mt-3">
                {getTags(selectedProject.tags).map((tag) => (
                  <span
                    key={tag}
                    className="text-xs font-medium bg-[rgba(30,58,95,0.08)] text-[#1E3A5F] px-3 py-1 rounded-full"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              <p className="text-[#888888] mt-4 leading-relaxed">
                {selectedProject.fullDescription || selectedProject.description}
              </p>

              <div className="mt-6">
                <h4 className="text-sm font-semibold text-[#111111] mb-2">Team</h4>
                <div className="flex flex-wrap gap-3">
                  {getAuthors(selectedProject.authors).map((author) => (
                    <div key={author.name} className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-[#1E3A5F] flex items-center justify-center text-white text-xs font-medium">
                        {author.name.charAt(0)}
                      </div>
                      <span className="text-sm text-[#888888]">{author.name}</span>
                    </div>
                  ))}
                </div>
              </div>

              {selectedProject.externalUrl && (
                <a
                  href={selectedProject.externalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 mt-6 text-[#1E3A5F] font-medium hover:underline"
                >
                  View Project
                  <ExternalLink className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes modalSlideUp {
          from {
            opacity: 0;
            transform: translateY(40px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </>
  );
}
