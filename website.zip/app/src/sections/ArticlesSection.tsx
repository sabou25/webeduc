import { useEffect, useRef } from "react";
import { trpc } from "@/providers/trpc";
import { ArrowRight, Clock } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function ArticlesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { data, isLoading } = trpc.article.list.useQuery({ limit: 3 });

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const cards = section.querySelectorAll(".article-card");
    const header = section.querySelector(".section-header");

    gsap.set(cards, { opacity: 0, y: 30 });
    if (header) gsap.set(header, { opacity: 0, y: 30 });

    const triggers: ScrollTrigger[] = [];

    if (header) {
      triggers.push(
        ScrollTrigger.create({
          trigger: header,
          start: "top 85%",
          onEnter: () => {
            gsap.to(header, { opacity: 1, y: 0, duration: 0.6, ease: "power2.out" });
          },
          once: true,
        })
      );
    }

    cards.forEach((card, i) => {
      triggers.push(
        ScrollTrigger.create({
          trigger: card,
          start: "top 85%",
          onEnter: () => {
            gsap.to(card, {
              opacity: 1,
              y: 0,
              duration: 0.6,
              delay: i * 0.08,
              ease: "power2.out",
            });
          },
          once: true,
        })
      );
    });

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, [data]);

  const fallbackArticles = [
    {
      id: 1,
      title: "The Neuroscience of Learning: How the Brain Absorbs Knowledge",
      excerpt: "Recent advances in neuroscience reveal how our brains form, store, and retrieve memories. Understanding these mechanisms can transform how we approach education.",
      thumbnail: "/article-1.jpg",
      category: "Research",
      authorName: "Dr. Sarah Mitchell",
      authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=sarah",
      publishedAt: new Date("2025-03-15"),
      readTime: 8,
    },
    {
      id: 2,
      title: "Rethinking Assessment: Beyond Standardized Testing",
      excerpt: "Standardized testing has dominated education for decades, but a growing body of evidence suggests alternative assessment methods may better capture student potential.",
      thumbnail: "/article-2.jpg",
      category: "Pedagogy",
      authorName: "Prof. James Chen",
      authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=james",
      publishedAt: new Date("2025-03-10"),
      readTime: 6,
    },
    {
      id: 3,
      title: "Collaborative Learning in the Digital Age",
      excerpt: "Technology has transformed how students collaborate. From virtual study groups to global classroom partnerships, the possibilities for peer learning have never been greater.",
      thumbnail: "/article-3.jpg",
      category: "Technology",
      authorName: "Dr. Emily Rodriguez",
      authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=emily",
      publishedAt: new Date("2025-03-05"),
      readTime: 5,
    },
  ];

  const articles = data?.items ?? fallbackArticles;

  return (
    <section
      id="articles"
      ref={sectionRef}
      className="bg-white"
      style={{ padding: "120px 0" }}
    >
      <div className="mx-auto px-6 lg:px-12" style={{ maxWidth: 1280 }}>
        <div className="section-header">
          <span className="font-mono-label text-xs uppercase tracking-[0.1em] text-[#D4A843]">
            ARTICLES
          </span>
          <h2 className="font-display text-[clamp(2rem,5vw,3.5rem)] font-semibold text-[#111111] mt-3 leading-tight">
            Insights & Research
          </h2>
          <p className="text-base text-[#888888] mt-3 max-w-[480px]">
            Deep dives into pedagogy, curriculum design, and learning science.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-16">
          {articles.map((article) => (
            <article
              key={article.id}
              className="article-card group cursor-pointer"
            >
              <div className="relative overflow-hidden rounded-lg aspect-video">
                <img
                  src={article.thumbnail || "/article-1.jpg"}
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                />
                <span className="absolute top-3 left-3 font-mono-label text-[0.6875rem] uppercase bg-[rgba(30,58,95,0.08)] text-[#1E3A5F] px-2.5 py-1 rounded">
                  {article.category}
                </span>
              </div>
              <h3 className="text-lg font-semibold text-[#111111] mt-4 leading-snug line-clamp-2 group-hover:text-[#1E3A5F] transition-colors">
                {article.title}
              </h3>
              <p className="text-sm text-[#888888] mt-2 line-clamp-3">
                {article.excerpt}
              </p>
              <div className="flex items-center gap-3 mt-4">
                <img
                  src={article.authorAvatar || ""}
                  alt={article.authorName || ""}
                  className="w-7 h-7 rounded-full object-cover"
                />
                <span className="text-xs text-[#888888]">
                  {article.authorName}
                </span>
                <span className="text-xs text-[#E5E5E5]">|</span>
                <span className="text-xs text-[#888888] flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {article.readTime} min read
                </span>
              </div>
            </article>
          ))}
        </div>

        <div className="flex justify-center mt-12">
          <button className="inline-flex items-center gap-2 text-[0.9375rem] font-medium text-[#1E3A5F] hover:gap-3 transition-all">
            View All Articles
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}
