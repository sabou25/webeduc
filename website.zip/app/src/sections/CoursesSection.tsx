import { useEffect, useRef } from "react";
import { trpc } from "@/providers/trpc";
import { Clock, Users, BookOpen, ArrowRight } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const levelColors: Record<string, string> = {
  beginner: "bg-green-100 text-green-700",
  intermediate: "bg-amber-100 text-amber-700",
  advanced: "bg-red-100 text-red-700",
};

export default function CoursesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { data, isLoading } = trpc.course.list.useQuery({ limit: 5 });

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const cards = section.querySelectorAll(".course-card");
    const header = section.querySelector(".section-header");

    gsap.set(cards, { opacity: 0, y: 30 });
    if (header) gsap.set(header, { opacity: 0, y: 30 });

    const triggers: ScrollTrigger[] = [];

    if (header) {
      triggers.push(
        ScrollTrigger.create({
          trigger: header,
          start: "top 85%",
          onEnter: () => {
            gsap.to(header, { opacity: 1, y: 0, duration: 0.6, ease: "power2.out" });
          },
          once: true,
        })
      );
    }

    cards.forEach((card, i) => {
      triggers.push(
        ScrollTrigger.create({
          trigger: card,
          start: "top 85%",
          onEnter: () => {
            gsap.to(card, {
              opacity: 1,
              y: 0,
              duration: 0.6,
              delay: i * 0.08,
              ease: "power2.out",
            });
          },
          once: true,
        })
      );
    });

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, [data]);

  const fallbackCourses = [
    {
      id: 1,
      title: "Introduction to Computational Thinking",
      slug: "computational-thinking",
      description: "Learn the fundamental concepts of computational thinking and problem-solving using algorithms, abstraction, and decomposition.",
      thumbnail: "/course-1.jpg",
      instructorName: "Prof. Alan Turing",
      instructorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=alan",
      duration: "12 weeks",
      level: "beginner",
      category: "Computer Science",
      featured: true,
      enrolledCount: 2340,
      lessonsCount: 48,
    },
    {
      id: 2,
      title: "Molecular Biology and Genetics",
      slug: "molecular-biology-genetics",
      description: "Explore the molecular mechanisms that govern life, from DNA replication to gene expression.",
      thumbnail: "/course-2.jpg",
      instructorName: "Dr. Rosalind Franklin",
      instructorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=rosalind",
      duration: "16 weeks",
      level: "advanced",
      category: "Life Sciences",
      featured: true,
      enrolledCount: 1890,
      lessonsCount: 64,
    },
    {
      id: 3,
      title: "History of Scientific Thought",
      slug: "history-scientific-thought",
      description: "Journey through the evolution of scientific thinking from ancient Greece to the modern era.",
      thumbnail: "/course-3.jpg",
      instructorName: "Prof. Thomas Kuhn",
      instructorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=thomas",
      duration: "10 weeks",
      level: "intermediate",
      category: "Humanities",
      featured: false,
      enrolledCount: 1456,
      lessonsCount: 40,
    },
    {
      id: 4,
      title: "Data Visualization and Communication",
      slug: "data-visualization",
      description: "Master the art of transforming complex data into compelling visual narratives.",
      thumbnail: "/course-4.jpg",
      instructorName: "Dr. Hans Rosling",
      instructorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=hans",
      duration: "8 weeks",
      level: "intermediate",
      category: "Data Science",
      featured: false,
      enrolledCount: 3120,
      lessonsCount: 32,
    },
    {
      id: 5,
      title: "Network Science: Connected World",
      slug: "network-science",
      description: "Understand the science of networks and how connectivity shapes everything from social media to neural pathways.",
      thumbnail: "/course-5.jpg",
      instructorName: "Prof. Albert-Laszlo Barabasi",
      instructorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=barabasi",
      duration: "14 weeks",
      level: "advanced",
      category: "Data Science",
      featured: false,
      enrolledCount: 980,
      lessonsCount: 56,
    },
  ];

  const courses = data?.items ?? fallbackCourses;
  const featured = courses.filter((c) => c.featured);
  const standard = courses.filter((c) => !c.featured);

  return (
    <section
      id="courses"
      ref={sectionRef}
      className="bg-[#F7F7F7]"
      style={{ padding: "120px 0" }}
    >
      <div className="mx-auto px-6 lg:px-12" style={{ maxWidth: 1280 }}>
        <div className="section-header">
          <span className="font-mono-label text-xs uppercase tracking-[0.1em] text-[#D4A843]">
            COURSES
          </span>
          <h2 className="font-display text-[clamp(2rem,5vw,3.5rem)] font-semibold text-[#111111] mt-3 leading-tight">
            Structured Learning Paths
          </h2>
          <p className="text-base text-[#888888] mt-3 max-w-[480px]">
            From foundational skills to advanced specializations.
          </p>
        </div>

        {/* Featured Courses */}
        {featured.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-16">
            {featured.map((course) => (
              <div
                key={course.id}
                className="course-card bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow duration-400 flex flex-col md:flex-row"
              >
                <div className="relative md:w-1/2 aspect-video md:aspect-auto">
                  <img
                    src={course.thumbnail || "/course-1.jpg"}
                    alt={course.title}
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute top-3 left-3 bg-[#1E3A5F] text-white font-mono-label text-[0.6875rem] px-2.5 py-1 rounded">
                    FEATURED
                  </span>
                </div>
                <div className="p-6 md:w-1/2 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xl font-semibold text-[#111111]">
                      {course.title}
                    </h3>
                    <p className="text-sm text-[#888888] mt-2 line-clamp-3">
                      {course.description}
                    </p>
                  </div>
                  <div className="mt-4 space-y-3">
                    <div className="flex items-center gap-2">
                      <img
                        src={course.instructorAvatar || ""}
                        alt={course.instructorName || ""}
                        className="w-6 h-6 rounded-full"
                      />
                      <span className="text-sm text-[#888888]">{course.instructorName}</span>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-[#888888]">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {course.duration}
                      </span>
                      <span className="flex items-center gap-1">
                        <BookOpen className="w-3.5 h-3.5" />
                        {course.lessonsCount} lessons
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="w-3.5 h-3.5" />
                        {course.enrolledCount?.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${levelColors[course.level || "beginner"]}`}>
                        {(course.level || "beginner").charAt(0).toUpperCase() + (course.level || "beginner").slice(1)}
                      </span>
                      <button className="bg-[#1E3A5F] text-white text-sm font-medium px-6 py-2.5 rounded-md hover:bg-[#152d4a] transition-colors">
                        Enroll
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Standard Courses */}
        {standard.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
            {standard.map((course) => (
              <div
                key={course.id}
                className="course-card bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-400 group"
              >
                <div className="relative aspect-video overflow-hidden">
                  <img
                    src={course.thumbnail || "/course-1.jpg"}
                    alt={course.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                  />
                </div>
                <div className="p-5">
                  <h3 className="text-[1.0625rem] font-semibold text-[#111111] line-clamp-2 group-hover:text-[#1E3A5F] transition-colors">
                    {course.title}
                  </h3>
                  <div className="flex items-center gap-2 mt-2">
                    <img
                      src={course.instructorAvatar || ""}
                      alt=""
                      className="w-5 h-5 rounded-full"
                    />
                    <span className="text-xs text-[#888888]">{course.instructorName}</span>
                    <span className="text-xs text-[#E5E5E5]">|</span>
                    <span className="text-xs text-[#888888] flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {course.duration}
                    </span>
                  </div>
                  <div className="flex items-center justify-between mt-4">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${levelColors[course.level || "beginner"]}`}>
                      {(course.level || "beginner").charAt(0).toUpperCase() + (course.level || "beginner").slice(1)}
                    </span>
                    <button className="text-sm font-medium text-[#1E3A5F] hover:underline">
                      Start Learning
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
