import { useEffect, useRef, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Play, Eye, X } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function VideosSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<{
    title: string;
    videoUrl: string | null;
  } | null>(null);

  const { data } = trpc.video.list.useQuery({ limit: 3 });

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const cards = section.querySelectorAll(".video-card");
    const header = section.querySelector(".section-header");

    gsap.set(cards, { opacity: 0, y: 30 });
    if (header) gsap.set(header, { opacity: 0, y: 30 });

    const triggers: ScrollTrigger[] = [];

    if (header) {
      triggers.push(
        ScrollTrigger.create({
          trigger: header,
          start: "top 85%",
          onEnter: () => {
            gsap.to(header, { opacity: 1, y: 0, duration: 0.6, ease: "power2.out" });
          },
          once: true,
        })
      );
    }

    cards.forEach((card, i) => {
      triggers.push(
        ScrollTrigger.create({
          trigger: card,
          start: "top 85%",
          onEnter: () => {
            gsap.to(card, {
              opacity: 1,
              y: 0,
              duration: 0.6,
              delay: i * 0.08,
              ease: "power2.out",
            });
          },
          once: true,
        })
      );
    });

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, [data]);

  const fallbackVideos = [
    {
      id: 1,
      title: "The Future of AI in Education",
      slug: "ai-in-education",
      description: "Explore how artificial intelligence is revolutionizing the educational landscape.",
      thumbnail: "/video-1.jpg",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
      duration: "24:30",
      channelName: "ScholarHub Lectures",
      viewCount: 45600,
      category: "Technology",
    },
    {
      id: 2,
      title: "Chemistry in Action: Spectacular Reactions",
      slug: "chemistry-reactions",
      description: "Watch as ordinary chemicals create extraordinary reactions.",
      thumbnail: "/video-2.jpg",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
      duration: "18:15",
      channelName: "Science Explained",
      viewCount: 28900,
      category: "Science",
    },
    {
      id: 3,
      title: "A Tour of the World's Most Beautiful Campuses",
      slug: "beautiful-campuses",
      description: "Take a virtual journey through stunning university campuses around the world.",
      thumbnail: "/video-3.jpg",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
      duration: "32:45",
      channelName: "Campus Life",
      viewCount: 67200,
      category: "Education",
    },
  ];

  const videos = data?.items ?? fallbackVideos;

  const openLightbox = (video: (typeof videos)[0]) => {
    setSelectedVideo({ title: video.title, videoUrl: video.videoUrl });
    setLightboxOpen(true);
    document.body.style.overflow = "hidden";
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
    document.body.style.overflow = "";
  };

  return (
    <>
      <section
        id="videos"
        ref={sectionRef}
        className="bg-[#111111]"
        style={{ padding: "120px 0" }}
      >
        <div className="mx-auto px-6 lg:px-12" style={{ maxWidth: 1280 }}>
          <div className="section-header">
            <span className="font-mono-label text-xs uppercase tracking-[0.1em] text-[#D4A843]">
              VIDEOS
            </span>
            <h2 className="font-display text-[clamp(2rem,5vw,3.5rem)] font-semibold text-white mt-3 leading-tight">
              Watch & Learn
            </h2>
            <p className="text-base text-white/60 mt-3 max-w-[480px]">
              Video lectures, tutorials, and documentary content.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-16">
            {videos.map((video) => (
              <div
                key={video.id}
                className="video-card group cursor-pointer"
                onClick={() => openLightbox(video)}
              >
                <div className="relative aspect-video rounded-lg overflow-hidden">
                  <img
                    src={video.thumbnail || "/video-1.jpg"}
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  {/* Dark overlay */}
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/50 transition-colors duration-300" />
                  {/* Play button */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-14 h-14 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
                      <Play className="w-6 h-6 text-[#111111] ml-1" fill="#111111" />
                    </div>
                  </div>
                  {/* Duration badge */}
                  <span className="absolute bottom-3 right-3 bg-black/70 text-white font-mono-label text-xs px-2 py-0.5 rounded">
                    {video.duration}
                  </span>
                </div>
                <h3 className="text-[1.0625rem] font-semibold text-white mt-4 leading-snug">
                  {video.title}
                </h3>
                <div className="flex items-center gap-3 mt-2 text-xs text-white/50">
                  <span>{video.channelName}</span>
                  <span className="flex items-center gap-1">
                    <Eye className="w-3 h-3" />
                    {video.viewCount?.toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox */}
      {lightboxOpen && selectedVideo && (
        <div
          className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4"
          onClick={closeLightbox}
        >
          <div
            className="relative max-w-4xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={closeLightbox}
              className="absolute -top-12 right-0 text-white/70 hover:text-white transition-colors"
            >
              <X className="w-8 h-8" />
            </button>
            <div className="aspect-video bg-black rounded-lg flex items-center justify-center">
              <div className="text-center text-white/60">
                <Play className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium text-white/80">{selectedVideo.title}</p>
                <p className="text-sm mt-2">Video player would load here</p>
              </div>
            </div>
            <p className="text-white/80 text-center mt-4 font-medium">{selectedVideo.title}</p>
          </div>
        </div>
      )}
    </>
  );
}
