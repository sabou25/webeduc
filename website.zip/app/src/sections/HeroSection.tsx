import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ChevronDown } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const words = [
  "Learning", "Discovery", "Education", "Knowledge", "Growth", "Insight",
  "Curiosity", "Mastery", "Wisdom", "Exploration", "Innovation", "Progress",
  "Understanding", "Achievement", "Excellence", "Creativity", "Critical Thinking",
  "Collaboration", "Research", "Analysis", "Synthesis", "Application",
  "Reflection", "Transformation",
];

const ITEM_COUNT = words.length;
const ANGLE_STEP = 360 / ITEM_COUNT;
const TRANSLATE_Z = "25vh";

export default function HeroSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const carouselRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const section = sectionRef.current;
    const carousel = carouselRef.current;
    if (!section || !carousel) return;

    // Main carousel rotation
    const rotationTween = gsap.to(carousel, {
      rotateX: -360,
      ease: "none",
      scrollTrigger: {
        trigger: section,
        start: "top top",
        end: "bottom bottom",
        scrub: true,
      },
    });

    // Word dimming based on position
    const dimTrigger = ScrollTrigger.create({
      trigger: section,
      start: "top top",
      end: "bottom bottom",
      onUpdate: () => {
        const progress = rotationTween.progress();
        const rotation = progress * 360;

        itemRefs.current.forEach((item, i) => {
          if (!item) return;
          const itemAngle = (i * ANGLE_STEP - rotation + 360) % 360;
          const normalizedAngle = itemAngle > 180 ? itemAngle - 360 : itemAngle;
          const opacity = Math.max(0.15, 1 - Math.abs(normalizedAngle) / 90);
          item.style.opacity = opacity.toFixed(2);
        });
      },
    });

    return () => {
      rotationTween.kill();
      dimTrigger.kill();
    };
  }, []);

  return (
    <div ref={sectionRef} className="relative" style={{ height: "150vh" }}>
      {/* Noise overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.03]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />

      <div className="perspective-container">
        <div ref={carouselRef} className="carousel-inner">
          {words.map((word, i) => (
            <div
              key={word}
              ref={(el) => { itemRefs.current[i] = el; }}
              className="carousel-item"
              style={{
                transform: `translate(-50%, -50%) rotateX(${i * ANGLE_STEP}deg) translateZ(${TRANSLATE_Z})`,
              }}
            >
              {word}
            </div>
          ))}
        </div>

        {/* Scroll hint */}
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
          <span className="text-sm text-[#888888]">Scroll to explore our world</span>
          <ChevronDown className="w-5 h-5 text-[#888888] animate-bounce" />
        </div>
      </div>
    </div>
  );
}
