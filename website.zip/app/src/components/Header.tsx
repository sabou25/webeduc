import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { Menu, X, ChevronDown, LogOut, User } from "lucide-react";

const navLinks = [
  { label: "Articles", href: "#articles" },
  { label: "Courses", href: "#courses" },
  { label: "Videos", href: "#videos" },
  { label: "Projects", href: "#projects" },
];

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Header() {
  const { user, isAuthenticated, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState("");
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);

      const sections = navLinks.map((link) => link.href.replace("#", ""));
      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 120) {
            setActiveSection(sections[i]);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const id = href.replace("#", "");
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#F7F7F7]/92 backdrop-blur-xl shadow-sm"
          : "bg-transparent"
      }`}
      style={{ height: 72 }}
    >
      <div className="mx-auto flex h-full items-center justify-between px-6 lg:px-12" style={{ maxWidth: 1280 }}>
        {/* Logo */}
        <Link to="/" className="flex items-center gap-0">
          <span className="font-display text-2xl font-bold text-[#111111]">
            ScholarHub
          </span>
          <span className="text-[#D4A843] text-2xl font-bold ml-0.5">.</span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.href}
              onClick={() => handleNavClick(link.href)}
              className={`text-[0.9375rem] font-medium transition-colors duration-150 ${
                activeSection === link.href.replace("#", "")
                  ? "text-[#1E3A5F] border-b-2 border-[#D4A843] pb-0.5"
                  : "text-[#111111] hover:text-[#1E3A5F]"
              }`}
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* Auth Section */}
        <div className="hidden md:flex items-center gap-4">
          {isAuthenticated && user ? (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                {user.avatar ? (
                  <img
                    src={user.avatar}
                    alt={user.name || "User"}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-[#1E3A5F] flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                )}
                <span className="text-sm font-medium text-[#111111]">
                  {user.name || "User"}
                </span>
              </div>
              <button
                onClick={logout}
                className="flex items-center gap-1.5 text-sm text-[#888888] hover:text-[#1E3A5F] transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => {
                window.location.href = getOAuthUrl();
              }}
              className="bg-[#1E3A5F] text-white px-5 py-2 rounded-full text-sm font-medium hover:bg-[#152d4a] transition-colors"
            >
              Sign In
            </button>
          )}
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden text-[#111111]"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#F7F7F7]/98 backdrop-blur-xl border-t border-[#E5E5E5]">
          <div className="px-6 py-4 space-y-3">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNavClick(link.href)}
                className="block w-full text-left text-base font-medium text-[#111111] hover:text-[#1E3A5F] py-2"
              >
                {link.label}
              </button>
            ))}
            <div className="pt-3 border-t border-[#E5E5E5]">
              {isAuthenticated && user ? (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {user.avatar ? (
                      <img src={user.avatar} alt="" className="w-8 h-8 rounded-full" />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-[#1E3A5F] flex items-center justify-center">
                        <User className="w-4 h-4 text-white" />
                      </div>
                    )}
                    <span className="text-sm font-medium">{user.name}</span>
                  </div>
                  <button
                    onClick={logout}
                    className="text-sm text-[#888888] hover:text-[#1E3A5F]"
                  >
                    Sign Out
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    window.location.href = getOAuthUrl();
                  }}
                  className="w-full bg-[#1E3A5F] text-white px-5 py-2.5 rounded-full text-sm font-medium"
                >
                  Sign In
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
