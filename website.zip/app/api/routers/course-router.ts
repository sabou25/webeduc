import { z } from "zod";
import { eq, desc, and, sql } from "drizzle-orm";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { courses } from "@db/schema";

export const courseRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        category: z.string().optional(),
        level: z.string().optional(),
        limit: z.number().min(1).max(50).default(12),
        offset: z.number().min(0).default(0),
        featured: z.boolean().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const params = input ?? { limit: 12, offset: 0 };

      const conditions = [];
      if (params.category) {
        conditions.push(eq(courses.category, params.category));
      }
      if (params.level) {
        conditions.push(eq(courses.level, params.level as "beginner" | "intermediate" | "advanced"));
      }
      if (params.featured !== undefined) {
        conditions.push(eq(courses.featured, params.featured));
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const [items, countResult] = await Promise.all([
        db
          .select()
          .from(courses)
          .where(whereClause)
          .orderBy(desc(courses.createdAt))
          .limit(params.limit)
          .offset(params.offset),
        db
          .select({ count: sql<number>`count(*)` })
          .from(courses)
          .where(whereClause),
      ]);

      return {
        items,
        total: Number(countResult[0]?.count ?? 0),
      };
    }),

  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(courses)
        .where(eq(courses.slug, input.slug))
        .limit(1);
      return result[0] ?? null;
    }),

  create: adminQuery
    .input(
      z.object({
        title: z.string().min(1),
        slug: z.string().min(1),
        description: z.string().optional(),
        thumbnail: z.string().optional(),
        instructorName: z.string().optional(),
        instructorAvatar: z.string().optional(),
        duration: z.string().optional(),
        level: z.enum(["beginner", "intermediate", "advanced"]).optional(),
        category: z.string().optional(),
        pdfUrl: z.string().optional(),
        externalUrl: z.string().optional(),
        featured: z.boolean().optional(),
        lessonsCount: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(courses).values(input);
      const inserted = await db
        .select()
        .from(courses)
        .where(eq(courses.id, Number(result[0].insertId)))
        .limit(1);
      return inserted[0];
    }),

  update: adminQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        slug: z.string().optional(),
        description: z.string().optional(),
        thumbnail: z.string().optional(),
        instructorName: z.string().optional(),
        instructorAvatar: z.string().optional(),
        duration: z.string().optional(),
        level: z.enum(["beginner", "intermediate", "advanced"]).optional(),
        category: z.string().optional(),
        pdfUrl: z.string().optional(),
        externalUrl: z.string().optional(),
        featured: z.boolean().optional(),
        lessonsCount: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(courses).set(data).where(eq(courses.id, id));
      const result = await db
        .select()
        .from(courses)
        .where(eq(courses.id, id))
        .limit(1);
      return result[0];
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(courses).where(eq(courses.id, input.id));
      return { success: true };
    }),
});
