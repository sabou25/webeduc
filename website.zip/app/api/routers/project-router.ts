import { z } from "zod";
import { eq, desc, and, sql } from "drizzle-orm";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { projects } from "@db/schema";

export const projectRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        category: z.string().optional(),
        limit: z.number().min(1).max(50).default(12),
        offset: z.number().min(0).default(0),
        featured: z.boolean().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const params = input ?? { limit: 12, offset: 0 };

      const conditions = [];
      if (params.category) {
        conditions.push(eq(projects.category, params.category));
      }
      if (params.featured !== undefined) {
        conditions.push(eq(projects.featured, params.featured));
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const [items, countResult] = await Promise.all([
        db
          .select()
          .from(projects)
          .where(whereClause)
          .orderBy(desc(projects.createdAt))
          .limit(params.limit)
          .offset(params.offset),
        db
          .select({ count: sql<number>`count(*)` })
          .from(projects)
          .where(whereClause),
      ]);

      return {
        items,
        total: Number(countResult[0]?.count ?? 0),
      };
    }),

  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(projects)
        .where(eq(projects.slug, input.slug))
        .limit(1);
      return result[0] ?? null;
    }),

  create: adminQuery
    .input(
      z.object({
        title: z.string().min(1),
        slug: z.string().min(1),
        description: z.string().optional(),
        fullDescription: z.string().optional(),
        coverImage: z.string().optional(),
        authors: z.array(z.object({ name: z.string(), avatar: z.string().optional() })).optional(),
        tags: z.array(z.string()).optional(),
        externalUrl: z.string().optional(),
        category: z.string().optional(),
        featured: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(projects).values(input);
      const inserted = await db
        .select()
        .from(projects)
        .where(eq(projects.id, Number(result[0].insertId)))
        .limit(1);
      return inserted[0];
    }),

  update: adminQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        slug: z.string().optional(),
        description: z.string().optional(),
        fullDescription: z.string().optional(),
        coverImage: z.string().optional(),
        authors: z.array(z.object({ name: z.string(), avatar: z.string().optional() })).optional(),
        tags: z.array(z.string()).optional(),
        externalUrl: z.string().optional(),
        category: z.string().optional(),
        featured: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(projects).set(data).where(eq(projects.id, id));
      const result = await db
        .select()
        .from(projects)
        .where(eq(projects.id, id))
        .limit(1);
      return result[0];
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(projects).where(eq(projects.id, input.id));
      return { success: true };
    }),
});
