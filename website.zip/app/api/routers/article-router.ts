import { z } from "zod";
import { eq, desc, and, sql } from "drizzle-orm";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { articles } from "@db/schema";

export const articleRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        category: z.string().optional(),
        limit: z.number().min(1).max(50).default(12),
        offset: z.number().min(0).default(0),
        featured: z.boolean().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const params = input ?? { limit: 12, offset: 0 };

      const conditions = [];
      if (params.category) {
        conditions.push(eq(articles.category, params.category));
      }
      if (params.featured !== undefined) {
        conditions.push(eq(articles.featured, params.featured));
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const [items, countResult] = await Promise.all([
        db
          .select()
          .from(articles)
          .where(whereClause)
          .orderBy(desc(articles.publishedAt))
          .limit(params.limit)
          .offset(params.offset),
        db
          .select({ count: sql<number>`count(*)` })
          .from(articles)
          .where(whereClause),
      ]);

      return {
        items,
        total: Number(countResult[0]?.count ?? 0),
      };
    }),

  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(articles)
        .where(eq(articles.slug, input.slug))
        .limit(1);
      return result[0] ?? null;
    }),

  create: adminQuery
    .input(
      z.object({
        title: z.string().min(1),
        slug: z.string().min(1),
        excerpt: z.string().optional(),
        content: z.string().optional(),
        thumbnail: z.string().optional(),
        category: z.string().optional(),
        authorName: z.string().optional(),
        authorAvatar: z.string().optional(),
        readTime: z.number().optional(),
        featured: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(articles).values({
        ...input,
        publishedAt: new Date(),
      });
      const inserted = await db
        .select()
        .from(articles)
        .where(eq(articles.id, Number(result[0].insertId)))
        .limit(1);
      return inserted[0];
    }),

  update: adminQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        slug: z.string().optional(),
        excerpt: z.string().optional(),
        content: z.string().optional(),
        thumbnail: z.string().optional(),
        category: z.string().optional(),
        authorName: z.string().optional(),
        authorAvatar: z.string().optional(),
        readTime: z.number().optional(),
        featured: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(articles).set(data).where(eq(articles.id, id));
      const result = await db
        .select()
        .from(articles)
        .where(eq(articles.id, id))
        .limit(1);
      return result[0];
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(articles).where(eq(articles.id, input.id));
      return { success: true };
    }),
});
