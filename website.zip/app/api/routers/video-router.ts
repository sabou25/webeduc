import { z } from "zod";
import { eq, desc, and, sql } from "drizzle-orm";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { videos } from "@db/schema";

export const videoRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        category: z.string().optional(),
        limit: z.number().min(1).max(50).default(12),
        offset: z.number().min(0).default(0),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const params = input ?? { limit: 12, offset: 0 };

      const conditions = [];
      if (params.category) {
        conditions.push(eq(videos.category, params.category));
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const [items, countResult] = await Promise.all([
        db
          .select()
          .from(videos)
          .where(whereClause)
          .orderBy(desc(videos.publishedAt))
          .limit(params.limit)
          .offset(params.offset),
        db
          .select({ count: sql<number>`count(*)` })
          .from(videos)
          .where(whereClause),
      ]);

      return {
        items,
        total: Number(countResult[0]?.count ?? 0),
      };
    }),

  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(videos)
        .where(eq(videos.slug, input.slug))
        .limit(1);
      return result[0] ?? null;
    }),

  create: adminQuery
    .input(
      z.object({
        title: z.string().min(1),
        slug: z.string().min(1),
        description: z.string().optional(),
        thumbnail: z.string().optional(),
        videoUrl: z.string().optional(),
        duration: z.string().optional(),
        channelName: z.string().optional(),
        viewCount: z.number().optional(),
        category: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(videos).values({
        ...input,
        publishedAt: new Date(),
      });
      const inserted = await db
        .select()
        .from(videos)
        .where(eq(videos.id, Number(result[0].insertId)))
        .limit(1);
      return inserted[0];
    }),

  update: adminQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        slug: z.string().optional(),
        description: z.string().optional(),
        thumbnail: z.string().optional(),
        videoUrl: z.string().optional(),
        duration: z.string().optional(),
        channelName: z.string().optional(),
        viewCount: z.number().optional(),
        category: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();
      await db.update(videos).set(data).where(eq(videos.id, id));
      const result = await db
        .select()
        .from(videos)
        .where(eq(videos.id, id))
        .limit(1);
      return result[0];
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(videos).where(eq(videos.id, input.id));
      return { success: true };
    }),
});
