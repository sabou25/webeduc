import { authRouter } from "./auth-router";
import { articleRouter } from "./routers/article-router";
import { courseRouter } from "./routers/course-router";
import { videoRouter } from "./routers/video-router";
import { projectRouter } from "./routers/project-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  article: articleRouter,
  course: courseRouter,
  video: videoRouter,
  project: projectRouter,
});

export type AppRouter = typeof appRouter;
